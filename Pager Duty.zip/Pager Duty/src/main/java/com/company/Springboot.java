package com.company;

public @interface Springboot {
}
