package com.company;

public class PagerDutyImpl extends PagerDuty {
}
