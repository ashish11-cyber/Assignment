package com.company;

public @interface RestController {
}
