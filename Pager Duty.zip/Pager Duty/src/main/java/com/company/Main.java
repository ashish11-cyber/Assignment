package com.PagerDuty;

public class PagerDuty
{
@Controller
@RestController
    public static void main(String[] args) {
	// write your code here
    @Springboot
    Scanner scan = new Scanner(System.in);
     Team t = new Team();
     Team id = id;
     Team name = name;
     Team name = Ashish;
     Team id = "101";
     Team claims = "win";
     Team claims = "loss";

     Developer d = new Developer();
     Developer id = id;
     Developer id = 101;
     Developer team_id;
     team_id = team_id;
     String team_id;
     team_id = "201";
     Developer name = name;
     Developer name = "Vijay";
     Developer phone_number = phone_number;
     Developer phone_number = "9981093211";

     System.out.println("Springboot application for team and developer: " + "team: + developer");
    }
}
